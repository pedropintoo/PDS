
public interface Ship {
	public String code();
	public String name();
}
