# Aula13 - Notes

to do
