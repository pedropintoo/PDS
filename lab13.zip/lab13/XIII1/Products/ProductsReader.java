package Products;

import java.util.List;

public interface ProductsReader {
    public List<Product> importFromProductsReader();
}
