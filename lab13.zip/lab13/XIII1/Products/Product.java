package Products;

public interface Product {
	String code();
	String description();
	double points();
}
